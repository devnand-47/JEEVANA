MAVEN Photography — demo website
Open index.html in a browser to preview.

To customize for a real client:
1. Replace business name, phone, text and WhatsApp number.
2. Replace the demo portfolio blocks with real photos.
3. Add the client's Instagram/social links.
4. Publish the folder using any static website host.
